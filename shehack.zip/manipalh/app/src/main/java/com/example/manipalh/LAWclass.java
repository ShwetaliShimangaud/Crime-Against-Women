package com.example.manipalh;

public class LAWclass
{
    String law;

    public String getLaw() {
        return law;
    }

    public void setLaw(String law) {
        this.law = law;
    }

    public LAWclass(String law) {
        this.law = law;
    }

    public LAWclass() {
    }
}
