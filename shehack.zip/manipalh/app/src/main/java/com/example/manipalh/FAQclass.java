package com.example.manipalh;

public class FAQclass
{
    String qa;

    public String getQa() {
        return qa;
    }

    public void setQa(String qa) {
        this.qa = qa;
    }

    public FAQclass(String qa) { this.qa = qa;
    }

    public FAQclass()
    {
    }
}
