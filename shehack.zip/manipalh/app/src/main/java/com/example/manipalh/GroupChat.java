package com.example.manipalh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GroupChat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);

    }
}
