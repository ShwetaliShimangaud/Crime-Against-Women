package com.example.manipalh;

public class VREPORT
{
    String report;

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public VREPORT(String report) {
        this.report = report;
    }

    public VREPORT() {
    }
}
